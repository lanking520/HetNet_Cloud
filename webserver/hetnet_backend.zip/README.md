

Install libraries

        pip install click, flask, sqlalchemy


Edit `server.py` to set your database URI

        DATABASEURI = "<your database uri>"


Run it in the shell


        python server.py

Get help:

        python server.py --help

      