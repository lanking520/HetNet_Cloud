from flask import render_template, Response
from . import routes
from application import *
import json
from flask import request
